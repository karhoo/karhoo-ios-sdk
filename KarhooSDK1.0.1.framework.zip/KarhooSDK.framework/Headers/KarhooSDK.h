//
//  KarhooSDK.h
//  KarhooSDK
//
//  
//  Copyright © 2020 Karhoo. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for KarhooSDK.
FOUNDATION_EXPORT double KarhooSDKVersionNumber;

//! Project version string for KarhooSDK.
FOUNDATION_EXPORT const unsigned char KarhooSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KarhooSDK/PublicHeader.h>

